﻿namespace Ejercicio04
{
    partial class fInicial
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMostrarFiguras = new System.Windows.Forms.Button();
            this.btnMostrarCirculos = new System.Windows.Forms.Button();
            this.btnMostrarCuadrados = new System.Windows.Forms.Button();
            this.btnCuadrado = new System.Windows.Forms.Button();
            this.btnCirculo = new System.Windows.Forms.Button();
            this.btnTriangulo = new System.Windows.Forms.Button();
            this.btnRectangulo = new System.Windows.Forms.Button();
            this.btnHexagono = new System.Windows.Forms.Button();
            this.btnMostrarTriangulos = new System.Windows.Forms.Button();
            this.btnMostrarRectangulos = new System.Windows.Forms.Button();
            this.btnMostrarHexagonos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMostrarFiguras
            // 
            this.btnMostrarFiguras.Location = new System.Drawing.Point(346, 57);
            this.btnMostrarFiguras.Name = "btnMostrarFiguras";
            this.btnMostrarFiguras.Size = new System.Drawing.Size(150, 57);
            this.btnMostrarFiguras.TabIndex = 14;
            this.btnMostrarFiguras.Text = "Mostrar Todas las Figuras";
            this.btnMostrarFiguras.UseVisualStyleBackColor = true;
            this.btnMostrarFiguras.Click += new System.EventHandler(this.btnMostrarFiguras_Click);
            // 
            // btnMostrarCirculos
            // 
            this.btnMostrarCirculos.Location = new System.Drawing.Point(586, 57);
            this.btnMostrarCirculos.Name = "btnMostrarCirculos";
            this.btnMostrarCirculos.Size = new System.Drawing.Size(150, 57);
            this.btnMostrarCirculos.TabIndex = 13;
            this.btnMostrarCirculos.Text = "Mostrar Circulos";
            this.btnMostrarCirculos.UseVisualStyleBackColor = true;
            this.btnMostrarCirculos.Click += new System.EventHandler(this.btnMostrarCirculos_Click);
            // 
            // btnMostrarCuadrados
            // 
            this.btnMostrarCuadrados.Location = new System.Drawing.Point(346, 148);
            this.btnMostrarCuadrados.Name = "btnMostrarCuadrados";
            this.btnMostrarCuadrados.Size = new System.Drawing.Size(150, 57);
            this.btnMostrarCuadrados.TabIndex = 12;
            this.btnMostrarCuadrados.Text = "Mostrar Cuadrados";
            this.btnMostrarCuadrados.UseVisualStyleBackColor = true;
            this.btnMostrarCuadrados.Click += new System.EventHandler(this.btnMostrarCuadrados_Click);
            // 
            // btnCuadrado
            // 
            this.btnCuadrado.Location = new System.Drawing.Point(47, 103);
            this.btnCuadrado.Name = "btnCuadrado";
            this.btnCuadrado.Size = new System.Drawing.Size(150, 37);
            this.btnCuadrado.TabIndex = 11;
            this.btnCuadrado.Text = "Introducir Cuadrado";
            this.btnCuadrado.UseVisualStyleBackColor = true;
            this.btnCuadrado.Click += new System.EventHandler(this.btnCuadrado_Click);
            // 
            // btnCirculo
            // 
            this.btnCirculo.Location = new System.Drawing.Point(47, 35);
            this.btnCirculo.Name = "btnCirculo";
            this.btnCirculo.Size = new System.Drawing.Size(150, 42);
            this.btnCirculo.TabIndex = 10;
            this.btnCirculo.Text = "Introducir Circulo";
            this.btnCirculo.UseVisualStyleBackColor = true;
            this.btnCirculo.Click += new System.EventHandler(this.btnCirculo_Click);
            // 
            // btnTriangulo
            // 
            this.btnTriangulo.Location = new System.Drawing.Point(47, 167);
            this.btnTriangulo.Name = "btnTriangulo";
            this.btnTriangulo.Size = new System.Drawing.Size(150, 38);
            this.btnTriangulo.TabIndex = 15;
            this.btnTriangulo.Text = "Introducir Triangulo";
            this.btnTriangulo.UseVisualStyleBackColor = true;
            this.btnTriangulo.Click += new System.EventHandler(this.btnTriangulo_Click);
            // 
            // btnRectangulo
            // 
            this.btnRectangulo.Location = new System.Drawing.Point(47, 238);
            this.btnRectangulo.Name = "btnRectangulo";
            this.btnRectangulo.Size = new System.Drawing.Size(150, 39);
            this.btnRectangulo.TabIndex = 16;
            this.btnRectangulo.Text = "Introducir Rectangulo";
            this.btnRectangulo.UseVisualStyleBackColor = true;
            this.btnRectangulo.Click += new System.EventHandler(this.btnRectangulo_Click);
            // 
            // btnHexagono
            // 
            this.btnHexagono.Location = new System.Drawing.Point(47, 302);
            this.btnHexagono.Name = "btnHexagono";
            this.btnHexagono.Size = new System.Drawing.Size(150, 39);
            this.btnHexagono.TabIndex = 17;
            this.btnHexagono.Text = "Introducir Hexagono";
            this.btnHexagono.UseVisualStyleBackColor = true;
            this.btnHexagono.Click += new System.EventHandler(this.btnHexagono_Click);
            // 
            // btnMostrarTriangulos
            // 
            this.btnMostrarTriangulos.Location = new System.Drawing.Point(586, 148);
            this.btnMostrarTriangulos.Name = "btnMostrarTriangulos";
            this.btnMostrarTriangulos.Size = new System.Drawing.Size(150, 57);
            this.btnMostrarTriangulos.TabIndex = 18;
            this.btnMostrarTriangulos.Text = "Mostrar Triangulos";
            this.btnMostrarTriangulos.UseVisualStyleBackColor = true;
            this.btnMostrarTriangulos.Click += new System.EventHandler(this.btnMostrarTriangulos_Click);
            // 
            // btnMostrarRectangulos
            // 
            this.btnMostrarRectangulos.Location = new System.Drawing.Point(346, 246);
            this.btnMostrarRectangulos.Name = "btnMostrarRectangulos";
            this.btnMostrarRectangulos.Size = new System.Drawing.Size(150, 56);
            this.btnMostrarRectangulos.TabIndex = 19;
            this.btnMostrarRectangulos.Text = "Introducir Rectangulos";
            this.btnMostrarRectangulos.UseVisualStyleBackColor = true;
            this.btnMostrarRectangulos.Click += new System.EventHandler(this.btnMostrarRectangulos_Click);
            // 
            // btnMostrarHexagonos
            // 
            this.btnMostrarHexagonos.Location = new System.Drawing.Point(586, 246);
            this.btnMostrarHexagonos.Name = "btnMostrarHexagonos";
            this.btnMostrarHexagonos.Size = new System.Drawing.Size(150, 56);
            this.btnMostrarHexagonos.TabIndex = 20;
            this.btnMostrarHexagonos.Text = "Mostrar Hexagonos";
            this.btnMostrarHexagonos.UseVisualStyleBackColor = true;
            this.btnMostrarHexagonos.Click += new System.EventHandler(this.btnMostrarHexagonos_Click);
            // 
            // fInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMostrarHexagonos);
            this.Controls.Add(this.btnMostrarRectangulos);
            this.Controls.Add(this.btnMostrarTriangulos);
            this.Controls.Add(this.btnHexagono);
            this.Controls.Add(this.btnRectangulo);
            this.Controls.Add(this.btnTriangulo);
            this.Controls.Add(this.btnMostrarFiguras);
            this.Controls.Add(this.btnMostrarCirculos);
            this.Controls.Add(this.btnMostrarCuadrados);
            this.Controls.Add(this.btnCuadrado);
            this.Controls.Add(this.btnCirculo);
            this.Name = "fInicial";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMostrarFiguras;
        private System.Windows.Forms.Button btnMostrarCirculos;
        private System.Windows.Forms.Button btnMostrarCuadrados;
        private System.Windows.Forms.Button btnCuadrado;
        private System.Windows.Forms.Button btnCirculo;
        private System.Windows.Forms.Button btnTriangulo;
        private System.Windows.Forms.Button btnRectangulo;
        private System.Windows.Forms.Button btnHexagono;
        private System.Windows.Forms.Button btnMostrarTriangulos;
        private System.Windows.Forms.Button btnMostrarRectangulos;
        private System.Windows.Forms.Button btnMostrarHexagonos;
    }
}

