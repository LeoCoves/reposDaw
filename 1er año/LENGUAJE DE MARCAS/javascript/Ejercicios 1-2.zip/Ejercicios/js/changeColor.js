let miBoton = document.getElementById("btnChange")
miBoton.addEventListener("click", function()
{
    document.body.style.backgroundColor = document.getElementById("colorFondo").value
})
