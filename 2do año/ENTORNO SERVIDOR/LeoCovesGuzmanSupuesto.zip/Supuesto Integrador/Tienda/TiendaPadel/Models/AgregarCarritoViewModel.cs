﻿namespace TiendaPadel.Models
{
    public class AgregarCarritoViewModel
    {
        public Producto ProductoActual { get; set; }
        public List<Producto> ProductosRelacionados { get; set; }
    }
}
